# Assignment3
This is a Shell made in C in Operating Systems Assignment2,
I have named this shell WonderShell (coughs Not related to wonder women) pls dont fork it Untill I do my assignemnt complete or I will be penalized

Describtion of Task3  

- shell support of the ‘&’ operator which lets a program to run in the background after printing the process id of the newly created process.
- Enable Input File Redirection , Output File Redirection and also Inut output File Redirection.
